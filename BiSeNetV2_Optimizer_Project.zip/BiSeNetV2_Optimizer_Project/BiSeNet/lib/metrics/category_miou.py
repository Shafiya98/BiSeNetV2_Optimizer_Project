import numpy as np

# 19 classes → 7 categories mapping (Cityscapes style grouping)
CATEGORY_MAP = {
    "road": [0],
    "sidewalk": [1],
    "building": [2, 3, 4],
    "vegetation": [8, 9],
    "sky": [10],
    "vehicle": [13, 14, 15, 16, 17, 18],
    "human": [11, 12]
}


def compute_category_miou(iou_per_class):
    """
    iou_per_class: np.array shape (19,)
    returns: dict {category: IoU}
    """

    cat_iou = {}

    for cat, cls_ids in CATEGORY_MAP.items():
        values = [iou_per_class[c] for c in cls_ids if c < len(iou_per_class)]
        cat_iou[cat] = float(np.mean(values)) if len(values) > 0 else 0.0

    return cat_iou