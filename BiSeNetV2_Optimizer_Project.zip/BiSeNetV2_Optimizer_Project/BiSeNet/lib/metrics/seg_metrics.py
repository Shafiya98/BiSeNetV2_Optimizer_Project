import numpy as np

def confusion_matrix(pred, label, num_classes):
    mask = (label >= 0) & (label < num_classes)

    hist = np.bincount(
        num_classes * label[mask].astype(int) + pred[mask],
        minlength=num_classes**2
    ).reshape(num_classes, num_classes)

    return hist


def compute_metrics(hist):

    iou = np.diag(hist) / (hist.sum(1) + hist.sum(0) - np.diag(hist) + 1e-6)
    miou = np.mean(iou)

    pixel_acc = np.sum(np.diag(hist)) / (hist.sum() + 1e-6)

    precision = np.diag(hist) / (hist.sum(0) + 1e-6)
    recall = np.diag(hist) / (hist.sum(1) + 1e-6)

    f1 = (2 * precision * recall) / (precision + recall + 1e-6)
    mean_f1 = np.mean(f1)

    mpa = np.mean(recall)

    return {
        "iou": iou,
        "miou": miou,
        "pixel_acc": pixel_acc,
        "mpa": mpa,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "mean_f1": mean_f1
    }