import numpy as np
import torch
from sklearn.metrics import roc_curve, auc


def compute_roc(model, loader, num_classes):

    model.eval()

    all_probs = []
    all_labels = []

    with torch.no_grad():
        for img, label in loader:

            img = img.cuda()
            label = label.cuda()

            out = model(img)[0]   # (B, C, H, W)

            probs = torch.softmax(out, dim=1)

            # -------------------------
            # FLATTEN PIXELS
            # -------------------------
            probs = probs.permute(0, 2, 3, 1).contiguous()
            probs = probs.view(-1, num_classes).cpu().numpy()

            label = label.view(-1).cpu().numpy()

            all_probs.append(probs)
            all_labels.append(label)

    all_probs = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)

    roc_results = {}

    for c in range(num_classes):

        y_true = (all_labels == c).astype(int)
        y_score = all_probs[:, c]

        # skip empty classes
        if np.sum(y_true) == 0:
            continue

        fpr, tpr, _ = roc_curve(y_true, y_score)

        roc_results[c] = {
            "fpr": fpr,
            "tpr": tpr,
            "auc": auc(fpr, tpr)
        }

    return roc_results