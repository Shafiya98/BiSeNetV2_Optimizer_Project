import csv
import os
import numpy as np


class CSVLogger:

    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)

        headers = [
            "epoch",
            "train_loss",
            "val_loss",
            "pixel_acc",
            "mIoU",
            "precision",
            "recall",
            "f1_score"
        ]

        with open(self.path, "w", newline="") as f:
            csv.writer(f).writerow(headers)

    def log(self, epoch, train_loss, metrics):

        with open(self.path, "a", newline="") as f:
            csv.writer(f).writerow([
                epoch,
                train_loss,
                metrics.get("val_loss", 0),
                metrics.get("pixel_acc", 0),
                metrics.get("miou", 0),
                float(np.mean(metrics.get("precision", 0))),
                float(np.mean(metrics.get("recall", 0))),
                metrics.get("mean_f1", 0)
            ])