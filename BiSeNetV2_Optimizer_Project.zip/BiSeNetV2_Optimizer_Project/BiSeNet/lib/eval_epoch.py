import torch
import numpy as np
from lib.metrics.seg_metrics import confusion_matrix, compute_metrics


def evaluate(model, loader, criterion, num_classes):

    model.eval()

    hist = np.zeros((num_classes, num_classes))
    val_loss = 0.0

    with torch.no_grad():
        for img, label in loader:

            img = img.cuda()
            label = label.cuda().squeeze(1)

            # forward
            out = model(img)

            # FIX: BiSeNet returns tuple/list
            if isinstance(out, (tuple, list)):
                out = out[0]

            # loss
            loss = criterion(out, label)
            val_loss += loss.item()

            # predictions
            pred = out.argmax(1).cpu().numpy()
            label_np = label.cpu().numpy()

            # confusion matrix update
            hist += confusion_matrix(pred, label_np, num_classes)

    # metrics from confusion matrix
    metrics = compute_metrics(hist)

    # add validation loss
    metrics["val_loss"] = val_loss / len(loader)

    return metrics
