import torch

def get_optimizer(params):

    return torch.optim.Adadelta(
        params,
        rho=0.9,
        eps=1e-6
    )