import torch

def get_optimizer(params):

    return torch.optim.Adamax(
        params,
        lr=0.002,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=0
    )