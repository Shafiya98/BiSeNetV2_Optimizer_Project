import torch

def get_optimizer(params):

    return torch.optim.Adagrad(
        params,
        lr=0.01,
        eps=1e-10,
        weight_decay=0
    )