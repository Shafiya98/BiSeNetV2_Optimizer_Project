import torch

def get_optimizer(params):

    return torch.optim.AdamW(
        params,
        lr=1e-4,
        betas=(0.9,0.999),
        weight_decay=0.01
    )