import torch

def get_optimizer(params):

    return torch.optim.Adam(
        params,
        lr=1e-4,
        betas=(0.9,0.999),
        eps=1e-8
    )