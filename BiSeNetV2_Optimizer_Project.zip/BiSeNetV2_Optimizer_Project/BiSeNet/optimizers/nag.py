import torch

def get_optimizer(params):

    return torch.optim.SGD(
        params,
        lr=0.05,
        momentum=0.9,
        nesterov=True,
        weight_decay=5e-4
    )