import torch

def get_optimizer(params):

    return torch.optim.RMSprop(
        params,
        lr=1e-4,
        alpha=0.99,
        eps=1e-8,
        momentum=0
    )