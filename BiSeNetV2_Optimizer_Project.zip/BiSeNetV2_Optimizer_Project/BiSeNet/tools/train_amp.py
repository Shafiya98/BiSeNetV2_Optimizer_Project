#!/usr/bin/python
# -*- encoding: utf-8 -*-

import sys
sys.path.insert(0, '.')

import os
import random
import logging
import argparse
import numpy as np
import csv

import torch
import torch.nn as nn
import torch.distributed as dist
import torch.cuda.amp as amp

from lib.models import model_factory
from configs import set_cfg_from_file
from lib.data import get_data_loader
from lib.ohem_ce_loss import OhemCELoss
from lib.lr_scheduler import WarmupPolyLrScheduler
from lib.logger import setup_logger
from optimizers.sgd_momentum import get_optimizer

from lib.eval_epoch import evaluate
from lib.metrics.seg_metrics import confusion_matrix, compute_metrics
from lib.metrics.category_miou import compute_category_miou


# ---------------- SEED ----------------
torch.manual_seed(42)
torch.cuda.manual_seed(42)
np.random.seed(42)
random.seed(42)

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = True


# ---------------- ARGS ----------------
def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--config',
        type=str,
        default='configs/bisenetv2.py'
    )

    parser.add_argument(
        '--finetune-from',
        type=str,
        default=None
    )

    parser.add_argument(
        '--resume',
        type=str,
        default=None
    )

    return parser.parse_args()


args = parse_args()
cfg = set_cfg_from_file(args.config)


# ---------------- MODEL ----------------
def set_model(lb_ignore=255):

    net = model_factory[cfg.model_type](cfg.n_cats)

    if args.finetune_from and args.resume is None:

        ckpt = torch.load(
            args.finetune_from,
            map_location='cpu'
        )

        if isinstance(ckpt, dict) and 'model' in ckpt:
            ckpt = ckpt['model']

        net.load_state_dict(
            ckpt,
            strict=False
        )

    if cfg.use_sync_bn:
        net = nn.SyncBatchNorm.convert_sync_batchnorm(net)

    net.cuda()
    net.train()

    criteria_pre = OhemCELoss(0.7, lb_ignore)

    criteria_aux = [
        OhemCELoss(0.7, lb_ignore)
        for _ in range(cfg.num_aux_heads)
    ]

    return net, criteria_pre, criteria_aux


# ---------------- OPTIM ----------------
def set_optimizer(model):
    return get_optimizer(model.parameters())


# ---------------- DDP ----------------
def set_model_dist(net):

    if 'LOCAL_RANK' in os.environ:

        local_rank = int(
            os.environ['LOCAL_RANK']
        )

        torch.cuda.set_device(
            local_rank
        )

        net = nn.parallel.DistributedDataParallel(
            net,
            device_ids=[local_rank],
            output_device=local_rank
        )

    return net


# =========================
# TRAIN
# =========================
def train():

    logger = logging.getLogger()

    train_loader = get_data_loader(
        cfg,
        mode='train'
    )

    val_loader = get_data_loader(
        cfg,
        mode='val'
    )

    net, criteria_pre, criteria_aux = set_model(
        train_loader.dataset.lb_ignore
    )

    optim = set_optimizer(
        net
    )

    scaler = amp.GradScaler()

    net = set_model_dist(
        net
    )

    lr_schdr = WarmupPolyLrScheduler(
        optim,
        power=0.9,
        max_iter=cfg.max_iter,
        warmup_iter=cfg.warmup_iters,
        warmup_ratio=0.1,
        warmup='exp',
        last_epoch=-1
    )

    # ---------- RESUME ----------
    start_epoch = 0

    if args.resume:

        ckpt = torch.load(
            args.resume,
            map_location='cpu'
        )

        if hasattr(net, "module"):
            net.module.load_state_dict(
                ckpt["model"]
            )
        else:
            net.load_state_dict(
                ckpt["model"]
            )

        if "optimizer" in ckpt:
            optim.load_state_dict(
                ckpt["optimizer"]
            )

        if "scheduler" in ckpt:
            lr_schdr.load_state_dict(
                ckpt["scheduler"]
            )

        start_epoch = ckpt["epoch"] + 1

        print(
            f"Resuming from epoch {start_epoch}"
        )

    os.makedirs(
        cfg.respth,
        exist_ok=True
    )

    csv_path = os.path.join(
        cfg.respth,
        "metrics.csv"
    )

    if not os.path.exists(csv_path):

        with open(
            csv_path,
            "w",
            newline=""
        ) as f:

            writer = csv.writer(f)

            writer.writerow([
                "epoch",
                "train_loss",
                "train_mIoU",
                "train_pixel_acc",
                "train_F1",
                "train_cat_mIoU",
                "val_loss",
                "val_mIoU",
                "val_pixel_acc",
                "val_F1",
                "val_cat_mIoU"
            ])

    iters_per_epoch = len(
        train_loader
    )

    for epoch in range(
        start_epoch,
        cfg.epochs
    ):

        net.train()

        epoch_loss = 0

        train_hist = np.zeros(
            (
                cfg.n_cats,
                cfg.n_cats
            )
        )

        for im, lb in train_loader:

            im = im.cuda()

            lb = lb.cuda().squeeze(1)

            optim.zero_grad()

            with amp.autocast(
                enabled=cfg.use_fp16
            ):

                logits, *logits_aux = net(im)

                loss_pre = criteria_pre(
                    logits,
                    lb
                )

                loss_aux = [
                    crit(l, lb)
                    for crit, l
                    in zip(
                        criteria_aux,
                        logits_aux
                    )
                ]

                loss = (
                    loss_pre +
                    sum(loss_aux)
                )

            scaler.scale(
                loss
            ).backward()

            scaler.step(
                optim
            )

            scaler.update()

            epoch_loss += (
                loss.item()
            )

            pred = logits.argmax(
                1
            ).detach().cpu().numpy()

            label_np = lb.detach().cpu().numpy()

            train_hist += confusion_matrix(
                pred,
                label_np,
                cfg.n_cats
            )

            lr_schdr.step()

        train_loss = (
            epoch_loss /
            iters_per_epoch
        )

        train_metrics = compute_metrics(
            train_hist
        )

        train_cat = compute_category_miou(
            train_metrics["iou"]
        )

        val_metrics = evaluate(
            net.module if hasattr(net, "module") else net,
            val_loader,
            criteria_pre,
            cfg.n_cats
        )

        val_cat = compute_category_miou(
            val_metrics["iou"]
        )

        with open(
            csv_path,
            "a",
            newline=""
        ) as f:

            writer = csv.writer(f)

            writer.writerow([
                epoch + 1,
                train_loss,
                train_metrics["miou"],
                train_metrics["pixel_acc"],
                train_metrics["mean_f1"],
                np.mean(list(train_cat.values())),
                val_metrics["val_loss"],
                val_metrics["miou"],
                val_metrics["pixel_acc"],
                val_metrics["mean_f1"],
                np.mean(list(val_cat.values()))
            ])

        if (not dist.is_initialized()) or dist.get_rank() == 0:

            torch.save({

                "epoch": epoch,

                "model":
                net.module.state_dict()
                if hasattr(net, "module")
                else net.state_dict(),

                "optimizer":
                optim.state_dict(),

                "scheduler":
                lr_schdr.state_dict()

            },

            os.path.join(
                cfg.respth,
                f"epoch_{epoch+1}.pth"
            ))

        logger.info(f"Epoch {epoch+1}")


def main():

    if 'LOCAL_RANK' in os.environ:

        local_rank = int(
            os.environ['LOCAL_RANK']
        )

        torch.cuda.set_device(
            local_rank
        )

        dist.init_process_group(
            backend='nccl'
        )

    setup_logger(
        f'{cfg.model_type}-train',
        cfg.respth
    )

    train()


if __name__ == "__main__":
    main()