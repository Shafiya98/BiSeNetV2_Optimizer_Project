#!/bin/bash

#SBATCH --job-name=optimizer2
#SBATCH --partition=shortq
#SBATCH --gres=gpu:h100_1g.12gb:1
#SBATCH --qos=shortq
#SBATCH --output=train_%j.log
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=02-00:00:00

source /apps/anaconda3/etc/profile.d/conda.sh

conda activate ahsan

cd /home/2022bite023/optimizer/BiSeNet

export PYTHONPATH=/home/2022bite023/optimizer/BiSeNet

python tools/train_amp.py \
--config configs/bisenetv2_city.py \
--resume res_sgd_momentum/epoch_163.pth